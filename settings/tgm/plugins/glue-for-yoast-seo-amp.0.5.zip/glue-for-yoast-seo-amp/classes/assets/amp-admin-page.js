jQuery(document).ready(function($){
    $('.yst_colorpicker').wpColorPicker();
});